sha-bang {#!/bin/bash)
python2 /Applications/PanelCheck/PanelCheck_V1.4.2_sourceCode/PanelCheck.py