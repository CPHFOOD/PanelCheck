

#Plots
from Line_Plot import *
from rawData_Plot import *
from Correlation_Plot import *
from profile_Plot import *
from Tucker1_Plot import *
from Eggshell_Plot import *
from pmse_Plot import *
from F_Plot import *
from MSE_Plot import *
from Consensus_Plot import *
#from STATIS_Plot import *
from MM_ANOVA_Plot import *
from Manhattan_Plot import *
from perfInd_Plot import *